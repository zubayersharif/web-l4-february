<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BPI</title>
    <?php wp_head(); ?>
</head>
<body>
    <header class="container">
        <div class="row logo">
            <div class="col-sm-6 logo_left">
                <?php the_custom_logo(); ?>
            </div>
            <div class="col-sm-6 menu_right navbar-expand text-end">
                <?php 
                wp_nav_menu([
                    'theme_location'=>'Top_Menu',
                    'menu_class'=> 'navbar-nav menu_ul'
                ]);
                ?>
            </div>
        </div>
    </header>