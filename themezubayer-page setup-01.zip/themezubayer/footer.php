<!-- footer part start -->
<footer class="container">
    <div class="row fb">
        <div class="col-sm-6">
            <h1>Address</h1>
        </div>
        <div class="col-sm-6 fb_right">
            <h1>Social Icons</h1>
        </div>
    </div>
</footer>
<!-- footer part end -->
<?php wp_footer(); ?>
</body>
</html>