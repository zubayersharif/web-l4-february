<?php get_header();?>

<div class="container ">
<?php
while(have_posts()):the_post(); 
?>
<div class="title-1">

<h1><a href=""><?php the_title(); ?></a></h1>
</div>


<div class="div">
<?php the_excerpt(); ?>
</div>



<?php endwhile; ?>

</div>



<?php get_footer();?>