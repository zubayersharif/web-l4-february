<?php get_header();?>

<div class="container ">
<h1>Error</h1>
</div>



<?php get_footer();?>