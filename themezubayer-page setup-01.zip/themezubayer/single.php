<?php get_header();?>

<div class="container ">

<div class="title-1">
<h1><?php the_title(); ?></h1>
</div>
<div class="div">
    <?php the_author();?>
</div>

<div class="div">
<?php the_post_thumbnail(); ?>
</div>
<div class="div">
<?php the_content(); ?>
</div>




</div>



<?php get_footer();?>